package com.traintracker.server.routes

import com.traintracker.server.database.AppDatabase
import com.traintracker.server.cif.CorpusLookup
import com.traintracker.server.database.Schedules
import com.traintracker.server.database.TrainLocations
import com.traintracker.server.kafka.trainLocations
import com.traintracker.server.hsp.HspClient
import com.traintracker.server.hsp.HspMetricsRequest
import io.ktor.http.*
import io.ktor.server.request.*
import io.ktor.server.application.*
import io.ktor.server.response.*
import io.ktor.server.routing.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.*
import org.jetbrains.exposed.sql.SortOrder
import org.jetbrains.exposed.sql.and
import org.jetbrains.exposed.sql.select
import org.jetbrains.exposed.sql.transactions.transaction
import java.time.LocalTime
import java.time.format.DateTimeFormatter

// ─── Response models ──────────────────────────────────────────────────────────

@Serializable
data class ServiceResponse(
    val uid: String,
    val headcode: String,
    val atocCode: String,
    val scheduledTime: String,
    val platform: String?,
    val isPass: Boolean,
    val stopType: String,
    val originTiploc: String,
    val destTiploc: String,
    val originCrs: String?,
    val destCrs: String?,
    val actualTime: String = "",
    val isCancelled: Boolean = false,
    val cancelReason: String? = null,
    val units: List<String> = emptyList(),
    val vehicles: List<String> = emptyList(),
    val unitJoinTiploc: String? = null,
    val couplingTiploc: String? = null,
    val couplingTiplocName: String? = null,
    val coupledFromUid: String? = null,
    val coupledFromHeadcode: String? = null,
    val formsUid: String? = null,
    val formsHeadcode: String? = null,
    val splitTiploc: String? = null,
    val splitTiplocName: String? = null,
    val splitToUid: String? = null,
    val splitToHeadcode: String? = null
)

@Serializable
data class CallingPointResponse(
    val tiploc: String,
    val crs: String?,
    val scheduledTime: String,
    val platform: String?,
    val isPass: Boolean,
    val stopType: String,
    val actualTime: String = "",
    val isCancelled: Boolean = false,
    val cancelReason: String? = null
)

@Serializable
data class ServiceDetailResponse(
    val uid: String,
    val atCrs: String,
    val previous: List<CallingPointResponse>,
    val subsequent: List<CallingPointResponse>
)

@Serializable
data class TrainLocationResponse(
    val headcode: String,
    val rid: String,
    val stationName: String,
    val crs: String?,
    val actualTime: String,
    val eventType: String,
    val delayMinutes: Int,
    val ageSeconds: Long
)

@Serializable
data class BoardResponse(
    val crs: String,
    val boardType: String,
    val windowStart: String,
    val windowEnd: String,
    val services: List<ServiceResponse>
)

@Serializable
data class AllocationResponse(
    val coreId:      String,
    val headcode:    String,
    val serviceDate: String,
    val operator:    String,
    val units:       List<String>,
    val vehicles:    List<String>,
    val unitCount:   Int,
    val coachCount:  Int
)

@Serializable
data class StatusResponse(
    val cifLastDownload: String?,
    val trustConnected: Boolean,
    val trainLocationsCount: Int
)

@Serializable
data class MovementResponse(
    val crs: String,
    val eventType: String,
    val scheduledTime: String,
    val actualTime: String,
    val platform: String,
    val isCancelled: Boolean
)

@Serializable
data class MovementsResponse(
    val headcode: String,
    val movements: List<MovementResponse>
)


fun Application.configureRoutes() {
    routing {
        route("/api") {

            // ── GET /api/status ────────────────────────────────────────────
            get("/status") {
                call.respond(
                    StatusResponse(
                        cifLastDownload     = AppDatabase.getCifMeta("last_download_date"),
                        trustConnected      = trainLocations.isNotEmpty(),
                        trainLocationsCount = trainLocations.size
                    )
                )
            }

            // ── GET /api/departures?crs=MAN&window=120 ────────────────────
            get("/departures") {
                val crs    = call.parameters["crs"]?.uppercase()?.trim()
                    ?: return@get call.respond(HttpStatusCode.BadRequest, "crs required")
                val window = call.parameters["window"]?.toIntOrNull() ?: 120
                val offset = call.parameters["offset"]?.toIntOrNull() ?: 0
                val (start, end) = timeWindow(window, offset)
                val services = queryBoard(crs, start, end, arrivalsOnly = false, passengerOnly = true, excludePassing = true)
                val board = BoardResponse(crs, "DEPARTURES", start, end, services)
                call.respond(board)
            }

            // ── GET /api/arrivals?crs=MAN&window=120 ──────────────────────
            get("/arrivals") {
                val crs    = call.parameters["crs"]?.uppercase()?.trim()
                    ?: return@get call.respond(HttpStatusCode.BadRequest, "crs required")
                val window = call.parameters["window"]?.toIntOrNull() ?: 120
                val offset = call.parameters["offset"]?.toIntOrNull() ?: 0
                val (start, end) = timeWindow(window, offset)
                val services = queryBoard(crs, start, end, arrivalsOnly = true, passengerOnly = true, excludePassing = true)
                val board = BoardResponse(crs, "ARRIVALS", start, end, services)
                call.respond(board)
            }

            // ── GET /api/service/{uid}?crs=MAN ────────────────────────────
            get("/service/{uid}") {
                val uid   = call.parameters["uid"]?.trim()
                    ?: return@get call.respond(HttpStatusCode.BadRequest, "uid required")
                val atCrs = call.parameters["crs"]?.uppercase()?.trim() ?: ""

                val trustMapForService = mutableMapOf<String, Triple<String, Boolean, String?>>()
                val callingPoints = transaction {
                    Schedules.select { Schedules.uid eq uid }
                        .orderBy(Schedules.scheduledTime, SortOrder.ASC)
                        .toList()
                        .filter { it[Schedules.stpIndicator] != 'C' }
                        .let { rows ->
                            val priority = mapOf('N' to 0, 'O' to 1, 'P' to 2, 'C' to 3)
                            val bestStp = rows.minOfOrNull { priority[it[Schedules.stpIndicator]] ?: 99 }
                            val bestRows = rows.filter { (priority[it[Schedules.stpIndicator]] ?: 99) == bestStp }
                            // Inherit missing stops from P schedule where overlay is incomplete
                            val bestSttpChar = priority.entries.find { it.value == bestStp }?.key
                            if (bestSttpChar != null && bestSttpChar != 'P') {
                                val hasOwnLo = bestRows.any { it[Schedules.stopType] == "LO" }
                                val hasOwnLt = bestRows.any { it[Schedules.stopType] == "LT" }
                                val hasOwnLi = bestRows.any { it[Schedules.stopType] == "LI" }
                                if (!hasOwnLo && !hasOwnLt) {
                                    // Partial modification: O rows are per-stop overrides within a P service
                                    // Merge all P rows with O rows taking precedence per tiploc
                                    val overriddenTiplocs = bestRows.map { it[Schedules.tiploc] }.toSet()
                                    val pRows = rows.filter {
                                        it[Schedules.stpIndicator] == 'P' && it[Schedules.tiploc] !in overriddenTiplocs
                                    }
                                    (bestRows + pRows).sortedBy { it[Schedules.scheduledTime] }
                                } else {
                                    val loTime = bestRows.firstOrNull { it[Schedules.stopType] == "LO" }?.get(Schedules.scheduledTime) ?: "00:00"
                                    val ltTime = bestRows.firstOrNull { it[Schedules.stopType] == "LT" }?.get(Schedules.scheduledTime) ?: "99:99"
                                    val overlayFirstTime = bestRows.minOfOrNull { it[Schedules.scheduledTime] } ?: "99:99"
                                    val pRows = rows.filter {
                                        it[Schedules.stpIndicator] == 'P' &&
                                        when (it[Schedules.stopType]) {
                                            "LO" -> !hasOwnLo && it[Schedules.scheduledTime] < overlayFirstTime
                                            "LI" -> (!hasOwnLo && it[Schedules.scheduledTime] < overlayFirstTime) ||
                                                    (hasOwnLo && !hasOwnLi && it[Schedules.scheduledTime] > loTime && it[Schedules.scheduledTime] < ltTime)
                                            else -> false
                                        }
                                    }
                                    (bestRows + pRows).sortedBy { it[Schedules.scheduledTime] }
                                }
                            } else bestRows
                        }
                        .let { rows ->
                            val priority = mapOf('N' to 0, 'O' to 1, 'P' to 2, 'C' to 3)
                            val bestStp = rows.minOfOrNull { priority[it[Schedules.stpIndicator]] ?: 99 }
                            val destRow = rows.firstOrNull {
                                (priority[it[Schedules.stpIndicator]] ?: 99) == bestStp &&
                                it[Schedules.stopType] == "LT"
                            }
                            val destTiploc = destRow?.get(Schedules.tiploc)
                            if (destTiploc != null) {
                                // Midnight-wrap: if LO time > LT time, sort post-midnight stops as 24:xx+
                                val loT = rows.firstOrNull { it[Schedules.stopType] == "LO" }?.get(Schedules.scheduledTime) ?: "00:00"
                                val ltT = rows.firstOrNull { it[Schedules.stopType] == "LT" }?.get(Schedules.scheduledTime) ?: "23:59"
                                val sorted = if (loT > ltT) {
                                    val loMins = loT.replace(":", "").toIntOrNull() ?: 0
                                    rows.sortedBy { r ->
                                        val mins = r[Schedules.scheduledTime].replace(":", "").toIntOrNull() ?: 0
                                        if (mins < loMins) mins + 2400 else mins
                                    }
                                } else rows.sortedBy { it[Schedules.scheduledTime] }
                                val ltIndex = sorted.indexOfFirst {
                                    it[Schedules.tiploc] == destTiploc && it[Schedules.stopType] == "LT"
                                }.let { if (it < 0) sorted.indexOfFirst { r -> r[Schedules.tiploc] == destTiploc } else it }
                                val deduped = sorted.filterIndexed { i, r ->
                                    r[Schedules.tiploc] != destTiploc || i == ltIndex
                                }
                                val finalIdx = deduped.indexOfFirst { it[Schedules.tiploc] == destTiploc }
                                if (finalIdx >= 0) deduped.subList(0, finalIdx + 1) else deduped
                            } else rows.sortedBy { it[Schedules.scheduledTime] }
                        }
                        .also { rows ->
                            // Build TRUST map for this service keyed by crs|scheduledTime
                            val headcode = rows.firstOrNull()?.get(Schedules.headcode) ?: ""
                            val safeHc = headcode.filter { it.isLetterOrDigit() }
                            if (safeHc.isNotEmpty()) {
                                exec("SELECT crs, stanox, scheduled_time, actual_time, is_cancelled, cancel_reason FROM trust_movements WHERE headcode='$safeHc' AND event_ts >= datetime('now', '-12 hours') ORDER BY event_ts DESC") { rs ->
                                    while (rs.next()) {
                                        val crs = rs.getString("crs")?.takeIf { it.isNotEmpty() }
                                            ?: CorpusLookup.crsFromStanox(rs.getString("stanox") ?: "") ?: continue
                                        val scht = rs.getString("scheduled_time") ?: continue
                                        val isCancelled = rs.getBoolean("is_cancelled")
                                        val cancelReason = rs.getString("cancel_reason")
                                        // CIF times are UTC, TRUST times are BST. Subtract 1h during BST.
                                        val bstOffset = if (java.util.TimeZone.getDefault().inDaylightTime(java.util.Date())) 60 else 0
                                        val rawActualT = rs.getString("actual_time") ?: ""
                                        val actualT = if (bstOffset > 0 && rawActualT.isNotEmpty()) {
                                            val p = rawActualT.split(":")
                                            if (p.size == 2) {
                                                val m = (p[0].toIntOrNull() ?: 0) * 60 + (p[1].toIntOrNull() ?: 0) - bstOffset
                                                "%02d:%02d".format((m + 1440) % 1440 / 60, (m + 1440) % 1440 % 60)
                                            } else rawActualT
                                        } else rawActualT
                                        val schtParts = scht.split(":")
                                        val utcScht = if (bstOffset > 0 && schtParts.size == 2) {
                                            val mins = (schtParts[0].toIntOrNull() ?: 0) * 60 + (schtParts[1].toIntOrNull() ?: 0) - bstOffset
                                            val adjusted = if (mins < 0) mins + 1440 else mins
                                            "%02d:%02d".format(adjusted / 60, adjusted % 60)
                                        } else scht
                                        for (key in listOf("$crs|$utcScht", "$crs|$scht")) {
                                            if (!trustMapForService.containsKey(key)) {
                                                trustMapForService[key] = Triple(actualT, isCancelled, cancelReason)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        .map { row ->
                            val tiploc = row[Schedules.tiploc]
                            val crs = row[Schedules.crs]?.takeIf { it.isNotEmpty() }
                                ?: CorpusLookup.crsFromTiploc(tiploc)
                            val trustEntry = if (crs != null) trustMapForService["$crs|${row[Schedules.scheduledTime]}"] else null
                            CallingPointResponse(
                                tiploc        = tiploc,
                                crs           = crs,
                                scheduledTime = row[Schedules.scheduledTime],
                                platform      = row[Schedules.platform],
                                isPass        = row[Schedules.isPass],
                                stopType      = row[Schedules.stopType],
                                actualTime    = trustEntry?.first ?: "",
                                isCancelled   = trustEntry?.second ?: false,
                                cancelReason  = trustEntry?.third
                            )
                        }
                        .let { rawCps ->
                            // Propagate last known delay to future stops without actual times.
                            // Only update lastDelayMins from TRUST-confirmed passenger stops (not passing points).
                            // Only propagate positive delays (don't project early running).
                            val trustConfirmedCrs = trustMapForService.keys.map { it.substringBefore("|") }.toSet()
                            var lastDelayMins = 0
                            rawCps.map { cp ->
                                val isTrustConfirmed = cp.actualTime.isNotEmpty() &&
                                    (cp.crs != null && trustConfirmedCrs.contains(cp.crs))
                                if (isTrustConfirmed) {
                                    // Update delay only from TRUST-confirmed stops
                                    val sch = cp.scheduledTime.split(":").let { p -> (p.getOrNull(0)?.toIntOrNull() ?: 0) * 60 + (p.getOrNull(1)?.toIntOrNull() ?: 0) }
                                    val act = cp.actualTime.split(":").let { p -> (p.getOrNull(0)?.toIntOrNull() ?: 0) * 60 + (p.getOrNull(1)?.toIntOrNull() ?: 0) }
                                    var diff = act - sch
                                    if (diff < -120) diff += 1440
                                    if (diff >= 0) lastDelayMins = diff  // Only update on late/on-time, not early
                                    cp
                                } else if (cp.actualTime.isEmpty() && lastDelayMins > 0 && !cp.isCancelled) {
                                    // Project positive delay onto stops with no TRUST actual
                                    val schMins = cp.scheduledTime.split(":").let { p -> (p.getOrNull(0)?.toIntOrNull() ?: 0) * 60 + (p.getOrNull(1)?.toIntOrNull() ?: 0) }
                                    val projMins = (schMins + lastDelayMins + 1440) % 1440
                                    cp.copy(actualTime = "%02d:%02d".format(projMins / 60, projMins % 60))
                                } else cp
                            }
                        }
                        .let { cps ->
                            // Fix midnight-wrap: if LO time > LT time, service crosses midnight.
                            // Re-sort by treating post-midnight times as 24:xx+
                            val loTime = cps.firstOrNull { it.stopType == "LO" }?.scheduledTime ?: "00:00"
                            val ltTime = cps.firstOrNull { it.stopType == "LT" }?.scheduledTime ?: "23:59"
                            if (loTime > ltTime) {
                                // Post-midnight stops (earlier than LO time) get +2400 so they sort after pre-midnight stops
                                cps.sortedBy { cp ->
                                    val mins = cp.scheduledTime.replace(":", "").toIntOrNull() ?: 0
                                    val loMins = loTime.replace(":", "").toIntOrNull() ?: 0
                                    if (mins < loMins) mins + 2400 else mins
                                }
                            } else cps
                        }
                }

                if (callingPoints.isEmpty()) {
                    call.respond(HttpStatusCode.NotFound, "Service $uid not found")
                    return@get
                }

                val atIndex    = callingPoints.indexOfFirst { it.crs == atCrs }
                    .let { if (it < 0 && atCrs.isNotEmpty()) callingPoints.indexOfFirst { cp -> cp.tiploc.startsWith(atCrs) } else if (it < 0) 0 else it }
                val previous   = if (atCrs.isNotEmpty() && atIndex > 0) callingPoints.subList(0, atIndex) else emptyList()
                val subsequent = if (atCrs.isEmpty()) callingPoints else if (atIndex >= 0 && atIndex + 1 < callingPoints.size) callingPoints.subList(atIndex + 1, callingPoints.size) else emptyList()

                call.respond(ServiceDetailResponse(uid, atCrs, previous, subsequent))
            }

            // ── GET /api/allservices?crs=MAN&window=120 ───────────────────
            get("/allservices") {
                val crs    = call.parameters["crs"]?.uppercase()?.trim()
                    ?: return@get call.respond(HttpStatusCode.BadRequest, "crs required")
                val window = call.parameters["window"]?.toIntOrNull() ?: 120
                val offset = call.parameters["offset"]?.toIntOrNull() ?: 0
                val (start, end) = timeWindow(window, offset)
                val services = queryBoard(crs, start, end, arrivalsOnly = true, passengerOnly = false, excludePassing = false)
                call.respond(BoardResponse(crs, "ALL", start, end, services))
            }

            // ── GET /api/trust/{headcode} ─────────────────────────────────
            get("/trust/{headcode}") {
                val headcode = call.parameters["headcode"]?.uppercase()?.trim()
                    ?: return@get call.respond(HttpStatusCode.BadRequest, "headcode required")

                val loc = trainLocations[headcode]
                if (loc != null) {
                    call.respond(TrainLocationResponse(
                        headcode     = loc.headcode,
                        rid          = loc.rid,
                        stationName  = loc.stationName,
                        crs          = loc.crs,
                        actualTime   = loc.actualTime,
                        eventType    = loc.eventType,
                        delayMinutes = loc.delayMinutes,
                        ageSeconds   = (System.currentTimeMillis() - loc.updatedEpochMs) / 1000
                    ))
                } else {
                    val dbLoc = transaction {
                        TrainLocations.select { TrainLocations.headcode eq headcode }.singleOrNull()
                    }
                    if (dbLoc != null) {
                        call.respond(TrainLocationResponse(
                            headcode     = dbLoc[TrainLocations.headcode],
                            rid          = dbLoc[TrainLocations.rid],
                            stationName  = dbLoc[TrainLocations.stationName],
                            crs          = dbLoc[TrainLocations.crs],
                            actualTime   = dbLoc[TrainLocations.actualTime],
                            eventType    = dbLoc[TrainLocations.eventType],
                            delayMinutes = dbLoc[TrainLocations.delayMinutes],
                            ageSeconds   = -1L
                        ))
                    } else {
                        call.respond(HttpStatusCode.NotFound, "No location data for $headcode")
                    }
                }
            }

            // ── GET /api/trust/locate/{rid} ───────────────────────────────
            get("/trust/locate/{rid}") {
                val rid = call.parameters["rid"]?.trim()
                    ?: return@get call.respond(HttpStatusCode.BadRequest, "rid required")
                // Search in-memory first
                val loc = trainLocations.values.firstOrNull { it.rid == rid }
                if (loc != null) {
                    call.respond(TrainLocationResponse(
                        headcode     = loc.headcode,
                        rid          = loc.rid,
                        stationName  = loc.stationName,
                        crs          = loc.crs,
                        actualTime   = loc.actualTime,
                        eventType    = loc.eventType,
                        delayMinutes = loc.delayMinutes,
                        ageSeconds   = (System.currentTimeMillis() - loc.updatedEpochMs) / 1000
                    ))
                } else {
                    val dbLoc = transaction {
                        TrainLocations.select { TrainLocations.rid eq rid }.singleOrNull()
                    }
                    if (dbLoc != null) {
                        call.respond(TrainLocationResponse(
                            headcode     = dbLoc[TrainLocations.headcode],
                            rid          = dbLoc[TrainLocations.rid],
                            stationName  = dbLoc[TrainLocations.stationName],
                            crs          = dbLoc[TrainLocations.crs],
                            actualTime   = dbLoc[TrainLocations.actualTime],
                            eventType    = dbLoc[TrainLocations.eventType],
                            delayMinutes = dbLoc[TrainLocations.delayMinutes],
                            ageSeconds   = -1L
                        ))
                    } else {
                        call.respond(HttpStatusCode.NotFound, "No location data for rid=$rid")
                    }
                }
            }
            // ── GET /api/trust/movements?headcode=1A34 ────────────────────
            get("/trust/movements") {
                val headcode = call.parameters["headcode"]?.uppercase()?.trim()
                    ?: return@get call.respond(HttpStatusCode.BadRequest, "headcode required")

                val safeHc = headcode.filter { it.isLetterOrDigit() }
                val movements = transaction {
                    val result = mutableListOf<MovementResponse>()
                    val bstOffset = if (java.util.TimeZone.getDefault().inDaylightTime(java.util.Date())) 60 else 0
                    fun bstToUtc(t: String): String {
                        if (bstOffset == 0 || t.isEmpty()) return t
                        val p = t.split(":")
                        if (p.size != 2) return t
                        val mins = (p[0].toIntOrNull() ?: 0) * 60 + (p[1].toIntOrNull() ?: 0) - bstOffset
                        val adj = (mins + 1440) % 1440
                        return "%02d:%02d".format(adj / 60, adj % 60)
                    }
                    exec("SELECT crs, stanox, event_type, scheduled_time, actual_time, platform, is_cancelled FROM trust_movements WHERE headcode='$safeHc' AND event_ts >= datetime('now', '-3 hours') ORDER BY event_ts DESC LIMIT 50") { rs ->
                        while (rs.next()) {
                            result.add(MovementResponse(
                                crs           = rs.getString("crs") ?: rs.getString("stanox") ?: "",
                                eventType     = rs.getString("event_type") ?: "",
                                scheduledTime = bstToUtc(rs.getString("scheduled_time") ?: ""),
                                actualTime    = bstToUtc(rs.getString("actual_time") ?: ""),
                                platform      = rs.getString("platform") ?: "",
                                isCancelled   = rs.getBoolean("is_cancelled")
                            ))
                        }
                    }
                    result
                }
                call.respond(MovementsResponse(headcode, movements))
            }

            // ── GET /api/headcode/{headcode} ──────────────────────────────
            // Returns all CIF schedule entries for a headcode today, enriched
            // with TRUST actual times and cancellation data. The response uses
            // the same ServiceResponse shape as /api/departures so the Android
            // board UI can render it without any changes.
            get("/headcode/{headcode}") {
                val headcode = call.parameters["headcode"]?.uppercase()?.trim()
                    ?: return@get call.respond(HttpStatusCode.BadRequest, "headcode required")
                val safeHc = headcode.filter { it.isLetterOrDigit() }

                val services = queryByHeadcode(safeHc)
                if (services.isEmpty()) {
                    call.respond(HttpStatusCode.NotFound, "No schedule found for headcode $headcode")
                } else {
                    call.respond(BoardResponse(
                        crs         = headcode,
                        boardType   = "HEADCODE",
                        windowStart = "00:00",
                        windowEnd   = "23:59",
                        services    = services
                    ))
                }
            }


            // ── GET /api/unit/{unit} ──────────────────────────────────────
            get("/unit/{unit}") {
                val unit = call.parameters["unit"]?.uppercase()?.trim()
                    ?: return@get call.respond(HttpStatusCode.BadRequest, "unit required")
                val safeUnit = unit.filter { it.isLetterOrDigit() }

                val services = queryByUnit(safeUnit)
                if (services.isEmpty()) {
                    call.respond(HttpStatusCode.NotFound, "No services found for unit $unit")
                } else {
                    call.respond(BoardResponse(
                        crs         = unit,
                        boardType   = "UNIT",
                        windowStart = "00:00",
                        windowEnd   = "23:59",
                        services    = services
                    ))
                }
            }
            // ── POST /api/hsp/metrics ──────────────────────────────────────
            post("/hsp/metrics") {
                if (!HspClient.isAvailable) {
                    call.respond(HttpStatusCode.ServiceUnavailable, mapOf("error" to "HSP not configured on server"))
                    return@post
                }
                val body = call.receiveText()
                val json = try { Json.parseToJsonElement(body).jsonObject } catch (_: Exception) {
                    call.respond(HttpStatusCode.BadRequest, mapOf("error" to "Invalid JSON body"))
                    return@post
                }
                val fromLoc = json["from_loc"]?.jsonPrimitive?.content?.uppercase()
                val fromDate = json["from_date"]?.jsonPrimitive?.content
                if (fromLoc == null || fromDate == null) {
                    call.respond(HttpStatusCode.BadRequest, mapOf("error" to "from_loc and from_date required"))
                    return@post
                }
                val req = HspMetricsRequest(
                    from_loc  = fromLoc,
                    to_loc    = json["to_loc"]?.jsonPrimitive?.content?.uppercase() ?: fromLoc,
                    from_time = json["from_time"]?.jsonPrimitive?.content ?: "0000",
                    to_time   = json["to_time"]?.jsonPrimitive?.content ?: "2359",
                    from_date = fromDate,
                    to_date   = json["to_date"]?.jsonPrimitive?.content ?: fromDate,
                    days      = json["days"]?.jsonPrimitive?.content ?: HspClient.daysParam(fromDate)
                )
                val result = withContext(Dispatchers.IO) { HspClient.getMetrics(req) }
                if (result != null) call.respond(result)
                else call.respond(HttpStatusCode.BadGateway, mapOf("error" to "HSP API request failed"))
            }

            // ── GET /api/hsp/metrics/stream ────────────────────────────────
            // Returns full merged result as JSON — client treats as single progress event
            // Query params: from, to, date, from_time (opt), to_time (opt)
            get("/hsp/metrics/stream") {
                if (!HspClient.isAvailable) {
                    call.respond(HttpStatusCode.ServiceUnavailable, mapOf("error" to "HSP not configured"))
                    return@get
                }
                val from     = call.parameters["from"]?.uppercase()?.trim()
                val to       = call.parameters["to"]?.uppercase()?.trim()
                val date     = call.parameters["date"]?.trim()
                val fromTime = call.parameters["from_time"]?.trim() ?: "0000"
                val toTime   = call.parameters["to_time"]?.trim()   ?: "2359"

                if (from == null || to == null || date == null) {
                    call.respond(HttpStatusCode.BadRequest, mapOf("error" to "from, to, date required"))
                    return@get
                }

                val req = HspMetricsRequest(
                    from_loc  = from,
                    to_loc    = to,
                    from_time = fromTime,
                    to_time   = toTime,
                    from_date = date,
                    to_date   = date,
                    days      = HspClient.daysParam(date)
                )
                val result = withContext(Dispatchers.IO) { HspClient.getMetrics(req) }
                if (result != null) call.respond(result)
                else call.respond(HttpStatusCode.BadGateway, mapOf("error" to "HSP API request failed"))
            }

            // ── POST /api/hsp/details ──────────────────────────────────────
            post("/hsp/details") {
                if (!HspClient.isAvailable) {
                    call.respond(HttpStatusCode.ServiceUnavailable, mapOf("error" to "HSP not configured on server"))
                    return@post
                }
                val body = call.receiveText()
                val json = try { Json.parseToJsonElement(body).jsonObject } catch (_: Exception) {
                    call.respond(HttpStatusCode.BadRequest, mapOf("error" to "Invalid JSON body"))
                    return@post
                }
                val rid = json["rid"]?.jsonPrimitive?.content?.trim()
                if (rid.isNullOrEmpty()) {
                    call.respond(HttpStatusCode.BadRequest, mapOf("error" to "rid required"))
                    return@post
                }
                val scheduledDep = json["scheduled_dep"]?.jsonPrimitive?.content?.trim() ?: ""
                val result = withContext(Dispatchers.IO) { HspClient.getDetails(rid) }
                if (result != null) {
                    val unitInfo = AppDatabase.getHspUnit(rid, scheduledDep)
                    val enriched = buildJsonObject {
                        put("rid",      result.rid)
                        put("date",     result.date)
                        put("tocCode",  result.tocCode)
                        put("unit",     unitInfo?.units?.firstOrNull() ?: "")
                        put("units",    Json.encodeToJsonElement(unitInfo?.units ?: emptyList<String>()))
                        put("vehicles", Json.encodeToJsonElement(unitInfo?.vehicles ?: emptyList<String>()))
                        put("unitCount", unitInfo?.unitCount ?: 0)
                        put("locations", buildJsonArray {
                            for (loc in result.locations) {
                                add(buildJsonObject {
                                    val crs  = CorpusLookup.crsFromTiploc(loc.tiploc)
                                    val name = loc.tiploc
                                    put("tiploc",        loc.tiploc)
                                    put("crs",           crs ?: "")
                                    put("name",          name)
                                    put("scheduledDep",  loc.scheduledDep)
                                    put("scheduledArr",  loc.scheduledArr)
                                    put("actualDep",     loc.actualDep)
                                    put("actualArr",     loc.actualArr)
                                    put("cancelReason",  loc.cancelReason)
                                })
                            }
                        })
                    }
                    call.respond(enriched)
                } else {
                    call.respond(HttpStatusCode.NotFound, mapOf("error" to "No HSP detail found for rid=$rid"))
                }
            }

            // ── GET /api/allocation/{param}?date=2026-03-27 ───────────────
            get("/allocation/{param}") {
                val param = call.parameters["param"]?.trim()
                    ?: return@get call.respond(HttpStatusCode.BadRequest, "coreId or headcode required")
                val date = call.request.queryParameters["date"]

                val results = AppDatabase.getAllocationByCoreId(param)
                    ?.let { listOf(it) }
                    ?: AppDatabase.getAllocationsByHeadcode(param.uppercase(), date)

                when {
                    results.isEmpty() ->
                        call.respond(HttpStatusCode.NotFound, "No allocation data for $param")
                    results.size == 1 -> {
                        val r = results.first()
                        call.respond(AllocationResponse(
                            coreId      = r.coreId,
                            headcode    = r.headcode,
                            serviceDate = r.serviceDate,
                            operator    = r.operator,
                            units       = r.units,
                            vehicles    = r.vehicles,
                            unitCount   = r.unitCount,
                            coachCount  = r.vehicles.size
                        ))
                    }
                    else ->
                        call.respond(results.map { r ->
                            AllocationResponse(
                                coreId      = r.coreId,
                                headcode    = r.headcode,
                                serviceDate = r.serviceDate,
                                operator    = r.operator,
                                units       = r.units,
                                vehicles    = r.vehicles,
                                unitCount   = r.unitCount,
                                coachCount  = r.vehicles.size
                            )
                        })
                }
            }

            // ── GET /api/allocation/uid/{uid} ─────────────────────────────
            get("/allocation/uid/{uid}") {
                val uid = call.parameters["uid"]?.trim()
                    ?: return@get call.respond(HttpStatusCode.BadRequest, "uid required")
                val result = AppDatabase.getAllocationByUid(uid)
                if (result == null) {
                    call.respond(HttpStatusCode.NotFound, "No allocation data for uid $uid")
                } else {
                    call.respond(AllocationResponse(
                        coreId      = result.coreId,
                        headcode    = result.headcode,
                        serviceDate = result.serviceDate,
                        operator    = result.operator,
                        units       = result.units,
                        vehicles    = result.vehicles,
                        unitCount   = result.unitCount,
                        coachCount  = result.vehicles.size
                    ))
                }
            }
            // ── POST /api/admin/snapshot-units?date=2026-03-27 ────────────────────
            post("/admin/snapshot-units") {
                val date = call.parameters["date"] ?: java.time.LocalDate.now().toString()
                withContext(Dispatchers.IO) { AppDatabase.snapshotUnitAllocations(date) }
                call.respond(mapOf("status" to "ok", "date" to date))
            }

        }
    }
}

// ─── Query helpers ────────────────────────────────────────────────────────────

/**
 * Returns all schedule rows for [headcode] across every station, deduplicated by UID
 * to one row per service (the origin LO stop), then enriched with TRUST data.
 *
 * The returned list uses the same [ServiceResponse] shape as queryBoard() so the
 * Android app can display a headcode search result identically to a normal board.
 */
private fun queryByHeadcode(headcode: String): List<ServiceResponse> {
    return transaction {
        // 1. Grab every schedule row for this headcode (all STP indicators, all stops)
        val allRows = Schedules.select { Schedules.headcode eq headcode }
            .orderBy(Schedules.scheduledTime, SortOrder.ASC)
            .toList()

        if (allRows.isEmpty()) return@transaction emptyList()

        // 2. For each UID, pick the highest-priority STP row (N > O > P, drop C)
        val priority = mapOf('N' to 0, 'O' to 1, 'P' to 2, 'C' to 3)
        val byUid = allRows.groupBy { it[Schedules.uid] }
        val bestRows = byUid.values.mapNotNull { rows ->
            val bestStp = rows.minOfOrNull { priority[it[Schedules.stpIndicator]] ?: 99 } ?: return@mapNotNull null
            if (priority.entries.find { it.value == bestStp }?.key == 'C') return@mapNotNull null
            // Use the LO (origin) stop row to represent the service
            rows.filter { (priority[it[Schedules.stpIndicator]] ?: 99) == bestStp }
                .minByOrNull { if (it[Schedules.stopType] == "LO") 0 else 1 }
        }

        // 3. Collect TRUST data for this headcode from the last 3 hours
        //    Key: scheduledTime (the LO departure time is unique per service)
        val trustMap = mutableMapOf<String, Triple<String, Boolean, String?>>()
        try {
            exec(
                "SELECT scheduled_time, actual_time, is_cancelled, cancel_reason " +
                "FROM trust_movements " +
                "WHERE headcode='$headcode' AND event_type='DEPARTURE' AND event_ts >= datetime('now', '-3 hours') " +
                "ORDER BY event_ts DESC"
            ) { rs ->
                while (rs.next()) {
                    val scht = rs.getString("scheduled_time") ?: continue
                    if (!trustMap.containsKey(scht)) {
                        trustMap[scht] = Triple(
                            rs.getString("actual_time") ?: "",
                            rs.getBoolean("is_cancelled"),
                            rs.getString("cancel_reason")
                        )
                    }
                }
            }
        } catch (_: Exception) {}

        // 4. Build ServiceResponse for each service, sorted by scheduled time
        bestRows.sortedBy { it[Schedules.scheduledTime] }.map { row ->
            val scht       = row[Schedules.scheduledTime]
            val trustEntry = trustMap[scht]
            ServiceResponse(
                uid           = row[Schedules.uid],
                headcode      = row[Schedules.headcode],
                atocCode      = row[Schedules.atocCode],
                scheduledTime = scht,
                platform      = row[Schedules.platform],
                isPass        = row[Schedules.isPass],
                stopType      = row[Schedules.stopType],
                originTiploc  = row[Schedules.originTiploc],
                destTiploc    = row[Schedules.destTiploc],
                originCrs     = row[Schedules.originCrs]?.takeIf { it.isNotEmpty() } ?: CorpusLookup.crsFromTiploc(row[Schedules.originTiploc]),
                destCrs       = row[Schedules.destCrs]?.takeIf { it.isNotEmpty() } ?: CorpusLookup.crsFromTiploc(row[Schedules.destTiploc]),
                actualTime    = trustEntry?.first ?: "",
                isCancelled   = trustEntry?.second ?: false,
                cancelReason  = trustEntry?.third
            )
        }
    }
}


private fun queryByUnit(unit: String): List<ServiceResponse> {
    return transaction {
        val today = java.time.LocalDate.now().toString()
        val rows = mutableListOf<ServiceResponse>()
        try {
            exec(
                "SELECT ac.headcode, ac.units, ac.vehicles, ac.operator, ac.core_id " +
                "FROM allocation_consists ac " +
                "WHERE (',' || ac.units || ',') LIKE '%,$unit,%' AND ac.service_date = '$today' AND SUBSTR(ac.units, 1, 3) = SUBSTR('$unit', 1, 3)"
            ) { rs ->
                while (rs.next()) {
                    val hc = rs.getString("headcode") ?: return@exec
                    val coreId = rs.getString("core_id") ?: return@exec
                    val safeHc = hc.filter { it.isLetterOrDigit() }
                    val uid = if (coreId.length > hc.length + 2)
                        coreId.substring(hc.length, coreId.length - 2) else null
                    val sched = if (uid != null) {
                        Schedules.select { Schedules.uid eq uid }
                            .orderBy(Schedules.scheduledTime, SortOrder.ASC)
                            .toList()
                            .filter { it[Schedules.stpIndicator] != 'C' }
                    } else {
                        Schedules.select { Schedules.headcode eq safeHc }
                            .orderBy(Schedules.scheduledTime, SortOrder.ASC)
                            .toList()
                            .filter { it[Schedules.stpIndicator] != 'C' }
                    }
                    val priority = mapOf('N' to 0, 'O' to 1, 'P' to 2, 'C' to 3)
                    val bestStp = sched.minOfOrNull { priority[it[Schedules.stpIndicator]] ?: 99 }
                    val best = sched.filter { (priority[it[Schedules.stpIndicator]] ?: 99) == bestStp }
                    val loRow = best.firstOrNull { it[Schedules.stopType] == "LO" } ?: best.firstOrNull() ?: return@exec
                    val unitList = (rs.getString("units") ?: "").split(",").map { it.trim() }.filter { it.isNotEmpty() }
                    val vehicleList = (rs.getString("vehicles") ?: "").split(",").map { it.trim() }.filter { it.isNotEmpty() }
                    val joinTiploc = if (loRow[Schedules.stopType] == "LI") loRow[Schedules.tiploc] else loRow[Schedules.originTiploc]
                    // Fetch full calling points for this service (needed for coupling detection)
                    val allStops = best.map { it[Schedules.tiploc] }.toSet()
                    rows.add(ServiceResponse(
                        uid           = loRow[Schedules.uid],
                        headcode      = hc,
                        atocCode      = loRow[Schedules.atocCode],
                        scheduledTime = loRow[Schedules.scheduledTime],
                        platform      = loRow[Schedules.platform],
                        isPass        = loRow[Schedules.isPass],
                        stopType      = loRow[Schedules.stopType],
                        originTiploc  = loRow[Schedules.originTiploc],
                        destTiploc    = loRow[Schedules.destTiploc],
                        originCrs     = loRow[Schedules.originCrs]?.takeIf { it.isNotEmpty() } ?: CorpusLookup.crsFromTiploc(loRow[Schedules.originTiploc]),
                        destCrs       = loRow[Schedules.destCrs]?.takeIf { it.isNotEmpty() } ?: CorpusLookup.crsFromTiploc(loRow[Schedules.destTiploc]),
                        actualTime    = "",
                        isCancelled   = false,
                        cancelReason  = null,
                        units         = unitList,
                        vehicles      = vehicleList,
                        unitJoinTiploc = joinTiploc
                    ))
                }
            }
        } catch (_: Exception) {}

        // ── Expand rows to include direct split partners only ────────────────────
        // Find services that originate at a tiploc on any primary service's route
        // and share at least one unit with that primary service.
        val seenUids = rows.map { it.uid }.toMutableSet()
        val extraRows = mutableListOf<ServiceResponse>()
        // Collect all tiplocs from primary services — batched in one query
        val primaryTiplocs = mutableMapOf<String, MutableSet<String>>()
        if (rows.isNotEmpty()) {
            try {
                val inClause = rows.map { "'${it.uid}'" }.toSet().joinToString(",")
                exec("SELECT uid, tiploc FROM schedules WHERE uid IN ($inClause) AND stp_indicator != 'C'") { rs ->
                    while (rs.next()) {
                        val u = rs.getString("uid") ?: continue
                        val t = rs.getString("tiploc") ?: continue
                        primaryTiplocs.getOrPut(u) { mutableSetOf() }.add(t)
                    }
                }
            } catch (_: Exception) {}
        }
        // For each primary service, find split partners via tiploc + unit overlap
        for (svc in rows.filter { it.units.size > 1 && unit in it.units }) {
            val myTiplocs2 = primaryTiplocs[svc.uid] ?: continue
            // Only expand on the partner units (not the searched unit itself)
            for (u in svc.units.filter { it != unit }) {
                try {
                    exec(
                        "SELECT ac.headcode, ac.units, ac.vehicles, ac.operator, ac.core_id " +
                        "FROM allocation_consists ac " +
                        "WHERE (',' || ac.units || ',') LIKE '%,$u,%' AND ac.service_date = '$today' " +
                        "AND ac.core_id NOT IN (${seenUids.joinToString(",") { "'${it.take(6)}'" }.ifEmpty { "''" }})"
                    ) { rs ->
                        while (rs.next()) {
                            val hc2 = rs.getString("headcode") ?: continue
                            val coreId2 = rs.getString("core_id") ?: continue
                            val uid2 = if (coreId2.length > hc2.length + 2)
                                coreId2.substring(hc2.length, coreId2.length - 2) else null
                            if (uid2 == null || uid2 in seenUids) continue
                            // Check this service originates at a tiploc on our route
                            val originTiploc2 = try {
                                var t = ""
                                exec("SELECT origin_tiploc FROM schedules WHERE uid = '$uid2' AND stop_type = 'LO' LIMIT 1") { rs2 ->
                                    if (rs2.next()) t = rs2.getString("origin_tiploc") ?: ""
                                }
                                t
                            } catch (_: Exception) { "" }
                            if (originTiploc2.isEmpty() || !myTiplocs2.contains(originTiploc2) || originTiploc2 == svc.originTiploc) continue
                            // Skip if the searched unit is already on this partner service
                            val partnerUnits = (rs.getString("units") ?: "").split(",").map { it.trim() }
                            if (unit in partnerUnits) continue
                            // Skip if the primary service terminates at the same point the partner originates
                            // (that's a join/coupling, handled separately, not a split)
                            if (svc.destTiploc == originTiploc2) continue
                            val sched2 = Schedules.select { Schedules.uid eq uid2 }
                                .orderBy(Schedules.scheduledTime, SortOrder.ASC)
                                .toList()
                                .filter { it[Schedules.stpIndicator] != 'C' }
                            val priority2 = mapOf('N' to 0, 'O' to 1, 'P' to 2, 'C' to 3)
                            val bestStp2 = sched2.minOfOrNull { priority2[it[Schedules.stpIndicator]] ?: 99 }
                            val best2 = sched2.filter { (priority2[it[Schedules.stpIndicator]] ?: 99) == bestStp2 }
                            val loRow2 = best2.firstOrNull { it[Schedules.stopType] == "LO" } ?: best2.firstOrNull() ?: continue
                            val unitList2 = (rs.getString("units") ?: "").split(",").map { it.trim() }.filter { it.isNotEmpty() }
                            val vehicleList2 = (rs.getString("vehicles") ?: "").split(",").map { it.trim() }.filter { it.isNotEmpty() }
                            val joinTiploc2 = if (loRow2[Schedules.stopType] == "LI") loRow2[Schedules.tiploc] else loRow2[Schedules.originTiploc]
                            seenUids.add(uid2)
                            extraRows.add(ServiceResponse(
                                uid           = loRow2[Schedules.uid],
                                headcode      = hc2,
                                atocCode      = loRow2[Schedules.atocCode],
                                scheduledTime = loRow2[Schedules.scheduledTime],
                                platform      = loRow2[Schedules.platform],
                                isPass        = loRow2[Schedules.isPass],
                                stopType      = loRow2[Schedules.stopType],
                                originTiploc  = loRow2[Schedules.originTiploc],
                                destTiploc    = loRow2[Schedules.destTiploc],
                                originCrs     = loRow2[Schedules.originCrs]?.takeIf { it.isNotEmpty() } ?: CorpusLookup.crsFromTiploc(loRow2[Schedules.originTiploc]),
                                destCrs       = loRow2[Schedules.destCrs]?.takeIf { it.isNotEmpty() } ?: CorpusLookup.crsFromTiploc(loRow2[Schedules.destTiploc]),
                                actualTime    = "",
                                isCancelled   = false,
                                cancelReason  = null,
                                units         = unitList2,
                                vehicles      = vehicleList2,
                                unitJoinTiploc = joinTiploc2
                            ))
                        }
                    }
                } catch (_: Exception) {}
            }
        }
                // Filter extraRows: only keep split partners whose units don't continue
        // on any primary service after the split (i.e. they genuinely leave the diagram)
        val primaryUnitsByTime = rows.flatMap { svc ->
            svc.units.map { u -> u to svc.scheduledTime }
        }.groupBy({ it.first }, { it.second })
        val filteredExtra = extraRows.filter { extra ->
            extra.units.all { u ->
                val primaryTimes = primaryUnitsByTime[u] ?: return@all true
                // Keep if the unit doesn't appear on any primary service after this split
                primaryTimes.none { t -> t > extra.scheduledTime }
            }
        }
        // allRows includes companion unit services for split detection
        val allRows = rows + filteredExtra
        val sorted = allRows.sortedBy { it.scheduledTime }


        // Build a map of uid -> full set of tiplocs — batched in one query
        val tiplocMap = mutableMapOf<String, MutableSet<String>>()
        if (sorted.isNotEmpty()) {
            try {
                val inClause = sorted.map { "'${it.uid}'" }.toSet().joinToString(",")
                exec("SELECT uid, tiploc FROM schedules WHERE uid IN ($inClause) AND stp_indicator != 'C' ORDER BY scheduled_time") { rs ->
                    while (rs.next()) {
                        val u = rs.getString("uid") ?: continue
                        val t = rs.getString("tiploc") ?: continue
                        tiplocMap.getOrPut(u) { mutableSetOf() }.add(t)
                    }
                }
            } catch (_: Exception) {}
        }

        // For each service, find what it forms next and any split portion
        sorted.map { svc ->
            val myTiplocs = tiplocMap[svc.uid] ?: emptySet()

            // SPLIT: another service originates mid-route on my route and takes a strict subset
            // of my units forward (some units split off, the rest continue with me)
            val splitPortion = sorted.filter { other ->
                other.uid != svc.uid &&
                other.originTiploc != svc.originTiploc &&
                other.originTiploc != svc.destTiploc &&
                myTiplocs.contains(other.originTiploc) &&
                other.units.isNotEmpty() && svc.units.size > 1 &&
                other.units.all { it in svc.units } &&
                other.units.size < svc.units.size &&
                !other.units.contains(unit) &&
                svc.units.contains(unit) &&
                other.scheduledTime >= svc.scheduledTime &&
                svc.units.filter { it != unit }.any { it in other.units }
            }.minByOrNull { it.scheduledTime }

            // FORMS NEXT: next service in the diagram sharing a unit with this one
            val formsNext = sorted.filter { other ->
                other.uid != svc.uid &&
                other.scheduledTime > svc.scheduledTime &&
                other.units.any { it in svc.units }
            }.minByOrNull { it.scheduledTime }

            var result = svc
            if (splitPortion != null) {
                result = result.copy(
                    splitTiploc     = splitPortion.originTiploc,
                    splitTiplocName = CorpusLookup.crsFromTiploc(splitPortion.originTiploc),
                    splitToUid      = splitPortion.uid,
                    splitToHeadcode = splitPortion.headcode
                )
            }
            // formsNext: only for services that actually carry the searched unit
            val formsSearchedUnit = if (svc.units.contains(unit)) sorted.filter { other ->
                other.uid != svc.uid &&
                other.scheduledTime > svc.scheduledTime &&
                other.units.contains(unit)
            }.minByOrNull { it.scheduledTime } else null
            if (formsSearchedUnit != null) {
                result = result.copy(
                    formsUid      = formsSearchedUnit.uid,
                    formsHeadcode = formsSearchedUnit.headcode
                )
            }
            result
        }.filter { it.units.isEmpty() || it.units.contains(unit) }  // remove companion unit services from final output
    }
}
private fun timeWindow(windowMinutes: Int, offsetMinutes: Int = 0): Pair<String, String> {
    val fmt = DateTimeFormatter.ofPattern("HH:mm")
    val start = LocalTime.now().plusMinutes(offsetMinutes.toLong())
    val end = start.plusMinutes(windowMinutes.toLong())
    val startStr = start.format(fmt)
    val endStr = end.format(fmt)
    return if (endStr < startStr) startStr to "23:59" else startStr to endStr
}

private fun queryBoard(
    crs: String,
    windowStart: String,
    windowEnd: String,
    arrivalsOnly: Boolean,
    passengerOnly: Boolean = false,
    excludePassing: Boolean = false
): List<ServiceResponse> {
    val crsGroup = listOf(crs)
    return transaction {
        val needed = listOf(
            Schedules.uid, Schedules.headcode, Schedules.atocCode,
            Schedules.scheduledTime, Schedules.platform, Schedules.isPass,
            Schedules.stopType, Schedules.stpIndicator, Schedules.crs,
            Schedules.originTiploc, Schedules.destTiploc,
            Schedules.originCrs, Schedules.destCrs
        )
        Schedules.slice(needed).select {
            (Schedules.crs inList crsGroup) and
            (Schedules.scheduledTime greaterEq windowStart) and
            (Schedules.scheduledTime lessEq windowEnd) and
            if (arrivalsOnly)
                (Schedules.stopType neq "LO")
            else
                (Schedules.stopType neq "LT")
        }
        .orderBy(Schedules.scheduledTime, SortOrder.ASC)
        .toList()
        .filter { row ->
            (!excludePassing || !row[Schedules.isPass]) &&
            (!passengerOnly || row[Schedules.headcode].firstOrNull()?.let { it in "1239" } == true)
        }
        .groupBy { it[Schedules.uid] }
        .values
        .let { groups ->
            val uidsWithOverride = mutableSetOf<String>()
            val pUids = groups.mapNotNull { rows ->
                val priority = mapOf('N' to 0, 'O' to 1, 'P' to 2, 'C' to 3)
                val best = rows.minByOrNull { priority[it[Schedules.stpIndicator]] ?: 99 } ?: return@mapNotNull null
                if (best[Schedules.stpIndicator] == 'P') best[Schedules.uid] else null
            }
            if (pUids.isNotEmpty()) {
                val inClause = pUids.joinToString(",") { "'$it'" }
                exec("SELECT DISTINCT uid FROM schedules WHERE uid IN ($inClause) AND stp_indicator IN ('O','N')") { rs ->
                    while (rs.next()) uidsWithOverride.add(rs.getString("uid") ?: "")
                }
            }
            groups.mapNotNull { rows ->
                val priority = mapOf('N' to 0, 'O' to 1, 'P' to 2, 'C' to 3)
                val best = rows.minByOrNull { priority[it[Schedules.stpIndicator]] ?: 99 }!!
                if (best[Schedules.stpIndicator] == 'P' && best[Schedules.uid] in uidsWithOverride) return@mapNotNull null
                best
            }
        }
        .filter { it[Schedules.stpIndicator] != 'C' }
        .sortedBy { it[Schedules.scheduledTime] }
        .let { sortedRows ->
            val safeCrsQ     = crs.filter { it.isLetterOrDigit() }
            val safeWinStart = windowStart.filter { it.isDigit() || it == ':' }
            val safeWinEnd   = windowEnd.filter   { it.isDigit() || it == ':' }
            val trustMap = mutableMapOf<String, Triple<String, Boolean, String?>>()
            val bstOffset = if (java.util.TimeZone.getDefault().inDaylightTime(java.util.Date())) 60 else 0
            fun bstToUtc(t: String): String {
                if (bstOffset == 0 || t.isEmpty()) return t
                val p = t.split(":")
                if (p.size != 2) return t
                val m = (p[0].toIntOrNull() ?: 0) * 60 + (p[1].toIntOrNull() ?: 0) - bstOffset
                return "%02d:%02d".format((m + 1440) % 1440 / 60, (m + 1440) % 1440 % 60)
            }
            try {
                exec("SELECT uid, headcode, scheduled_time, actual_time, is_cancelled, cancel_reason FROM trust_movements WHERE crs='$safeCrsQ' AND scheduled_time >= time('$safeWinStart', '-5 minutes') AND scheduled_time <= time('$safeWinEnd', '+5 minutes') AND event_ts >= datetime('now', '-3 hours') ORDER BY event_ts DESC") { rs ->
                    while (rs.next()) {
                        val uid  = rs.getString("uid")?.takeIf { it.isNotEmpty() }
                        val hc   = rs.getString("headcode") ?: continue
                        val scht = rs.getString("scheduled_time") ?: continue
                        val utcActual = bstToUtc(rs.getString("actual_time") ?: "")
                        val triple = Triple(utcActual, rs.getBoolean("is_cancelled"), rs.getString("cancel_reason"))
                        if (uid != null) {
                            if (!trustMap.containsKey(uid)) trustMap[uid] = triple
                        }
                        val utcScht = bstToUtc(scht)
                        for (offset in listOf(0, 1, -1)) {
                            val adj = utcScht.split(":").let { p -> (p[0].toIntOrNull() ?: 0) * 60 + (p[1].toIntOrNull() ?: 0) + offset }
                            val adjTime = "%02d:%02d".format((adj + 1440) % 1440 / 60, (adj + 1440) % 1440 % 60)
                            val fallbackKey = "$hc|$adjTime"
                            if (!trustMap.containsKey(fallbackKey)) trustMap[fallbackKey] = triple
                        }
                    }
                }
            } catch (_: Exception) {}
            sortedRows.map { row ->
                val hc                 = row[Schedules.headcode]
                val scht               = row[Schedules.scheduledTime]
                val trustEntry         = trustMap[row[Schedules.uid]] ?: trustMap["$hc|$scht"]
                val actualTime         = trustEntry?.first ?: ""
                val isCancelledByTrust = trustEntry?.second ?: false
                val cancelReasonCode   = trustEntry?.third
                ServiceResponse(
                    uid           = row[Schedules.uid],
                    headcode      = row[Schedules.headcode],
                    atocCode      = row[Schedules.atocCode],
                    scheduledTime = row[Schedules.scheduledTime],
                    platform      = row[Schedules.platform],
                    isPass        = row[Schedules.isPass],
                    stopType      = row[Schedules.stopType],
                    originTiploc  = row[Schedules.originTiploc],
                    destTiploc    = row[Schedules.destTiploc],
                    originCrs     = row[Schedules.originCrs]?.takeIf { it.isNotEmpty() } ?: CorpusLookup.crsFromTiploc(row[Schedules.originTiploc]),
                    destCrs       = row[Schedules.destCrs]?.takeIf { it.isNotEmpty() } ?: CorpusLookup.crsFromTiploc(row[Schedules.destTiploc]),
                    actualTime    = actualTime,
                    isCancelled   = isCancelledByTrust,
                    cancelReason  = cancelReasonCode
                )
            }
        }
    }
}
